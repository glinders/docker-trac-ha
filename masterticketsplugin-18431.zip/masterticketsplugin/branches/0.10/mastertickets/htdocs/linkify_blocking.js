$(function() {
    $('td[@headers=h_blocking]').html($('#linkified_blocking').html());
});