$(function() {
   $('#resolve').attr('disabled', 'disabled'); 
});