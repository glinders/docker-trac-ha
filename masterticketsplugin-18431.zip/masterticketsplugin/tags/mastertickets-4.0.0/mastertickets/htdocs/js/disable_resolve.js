$(function () {
  $("#action_resolve_resolve_resolution").find("option[text='fixed']").attr('disabled', 'disabled').removeAttr('selected');
});
