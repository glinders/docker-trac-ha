$(function () {
  $("#action_resolve_resolve_resolution option[text='fixed']").attr('disabled', 'disabled').removeAttr('selected');
});
