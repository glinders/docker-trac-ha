jQuery(function ($) {
  $('td[@headers=h_blockedby]').html($('#linkified_blockedby').html());
});
