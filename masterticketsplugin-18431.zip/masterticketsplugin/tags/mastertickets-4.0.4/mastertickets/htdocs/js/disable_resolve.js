jQuery(function ($) {
  $("#action_resolve_resolve_resolution").find("option[value='fixed']").attr('disabled', 'disabled').removeAttr('selected');
});
