import pkg_resources
pkg_resources.require('Trac >= 1.2')
pkg_resources.require('Trac < 1.5')
