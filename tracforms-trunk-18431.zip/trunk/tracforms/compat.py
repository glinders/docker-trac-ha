# -*- coding: utf-8 -*-

try:
    import json
except ImportError:
    import simplejson as json
